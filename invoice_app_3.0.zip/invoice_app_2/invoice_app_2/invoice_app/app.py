import streamlit as st
import google.generativeai as genai
import pandas as pd
import json
import os
import io
import re
from dotenv import load_dotenv
from openpyxl.styles import Font, Alignment, PatternFill, numbers
from openpyxl.utils import get_column_letter
import hashlib
from datetime import datetime, timedelta
import base64
import secrets
import sqlite3
import qrcode
from PIL import Image
import io
import time
from cryptography.fernet import Fernet
import uuid
from typing import Dict, List, Tuple, Optional
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import warnings
warnings.filterwarnings('ignore')

# --- Configuration and Setup ---
load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY")
API_KEY = "AIzaSyD_WWpfEdXu-7PAmSL9pI67IqTQ67Pa9yk"  # Replace with your key if needed

if not API_KEY:
    st.error("⚠️ No API key found. Please set GEMINI_API_KEY in your environment or .env file.")
else:
    genai.configure(api_key=API_KEY)

# Initialize Gemini Model
model = genai.GenerativeModel("gemini-2.5-flash-preview-05-20")

# --- Database and Security Setup ---
DB_PATH = os.path.join(os.path.dirname(__file__), "invoice_app.db")
ENCRYPTION_KEY_FILE = os.path.join(os.path.dirname(__file__), ".encryption_key")

def get_or_create_encryption_key():
    """Get or create encryption key for data security"""
    if os.path.exists(ENCRYPTION_KEY_FILE):
        with open(ENCRYPTION_KEY_FILE, 'rb') as f:
            return f.read()
    else:
        key = Fernet.generate_key()
        with open(ENCRYPTION_KEY_FILE, 'wb') as f:
            f.write(key)
        return key

def init_database():
    """Initialize SQLite database with encrypted storage"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Users table with 2FA support
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            two_factor_enabled BOOLEAN DEFAULT 0,
            two_factor_secret TEXT,
            last_login TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT 1,
            login_attempts INTEGER DEFAULT 0,
            locked_until TIMESTAMP
        )
    ''')
    
    # Documents table with encryption support
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            filename TEXT NOT NULL,
            file_hash TEXT NOT NULL,
            document_type TEXT,
            extracted_data TEXT, -- JSON encrypted
            processing_status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Audit log for GDPR compliance
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            details TEXT,
            ip_address TEXT,
            user_agent TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Rate limiting table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS rate_limits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            endpoint TEXT NOT NULL,
            requests_count INTEGER DEFAULT 1,
            window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    conn.commit()
    conn.close()

# Initialize database
init_database()
ENCRYPTION_KEY = get_or_create_encryption_key()
FERNET = Fernet(ENCRYPTION_KEY)

# --- UI/UX Configuration ---
# Page config for better mobile experience
st.set_page_config(
    page_title="Document Data Extractor",
    page_icon="📑",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Theme configuration
if "theme" not in st.session_state:
    st.session_state.theme = "light"

# Custom CSS for better styling
def apply_custom_css(theme="light"):
    if theme == "dark":
        css = """
        <style>
        /* Dark theme styles */
        .stApp {
            background-color: #0e1117;
            color: #ffffff;
        }
        
        /* Main container styling */
        .main .block-container {
            padding-top: 2rem;
            padding-bottom: 2rem;
            max-width: 1200px;
            background-color: #0e1117;
        }
        
        /* Header styling - dark theme */
        .main-header {
            background: linear-gradient(90deg, #2d3748 0%, #4a5568 100%);
            padding: 2rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            color: white;
            text-align: center;
            border: 1px solid #4a5568;
        }
        
        .main-header h1 {
            color: white !important;
            margin: 0;
            font-size: 2.5rem;
        }
        
        /* Upload area styling - dark theme */
        .upload-area {
            border: 2px dashed #4a5568;
            border-radius: 10px;
            padding: 2rem;
            text-align: center;
            background: #1a202c;
            margin: 1rem 0;
            transition: all 0.3s ease;
            color: #e2e8f0;
        }
        
        .upload-area:hover {
            border-color: #667eea;
            background: #2d3748;
        }
        
        /* Card styling for results - dark theme */
        .result-card {
            background: #1a202c;
            border-radius: 10px;
            padding: 1.5rem;
            margin: 1rem 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            border-left: 4px solid #667eea;
            color: #e2e8f0;
            border: 1px solid #4a5568;
        }
        
        /* Button styling - dark theme */
        .stButton > button {
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 25px;
            padding: 0.5rem 2rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .stButton > button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        /* Metric cards - dark theme */
        .metric-card {
            background: linear-gradient(135deg, #2d3748 0%, #4a5568 100%);
            color: white;
            padding: 1.5rem;
            border-radius: 10px;
            text-align: center;
            margin: 0.5rem;
            border: 1px solid #4a5568;
        }
        
        /* Sidebar styling - dark theme */
        .css-1d391kg {
            background-color: #1a202c;
            border-right: 1px solid #4a5568;
        }
        
        /* Text inputs and selects - dark theme */
        .stTextInput > div > div > input,
        .stSelectbox > div > div > select {
            background-color: #2d3748;
            color: #e2e8f0;
            border: 1px solid #4a5568;
        }
        
        /* Dataframe styling - dark theme */
        .stDataFrame {
            background-color: #1a202c;
            color: #e2e8f0;
        }
        
        /* Loading spinner customization */
        .stSpinner > div {
            border-top-color: #667eea;
        }
        
        /* Responsive design */
        @media (max-width: 768px) {
            .main-header h1 {
                font-size: 1.8rem;
            }
            .upload-area {
                padding: 1rem;
            }
            .result-card {
                padding: 1rem;
            }
        }
        </style>
        """
    else:
        css = """
        <style>
        /* Light theme styles */
        .stApp {
            background-color: #ffffff;
            color: #262730;
        }
        
        /* Main container styling */
        .main .block-container {
            padding-top: 2rem;
            padding-bottom: 2rem;
            max-width: 1200px;
            background-color: #ffffff;
        }
        
        /* Header styling */
        .main-header {
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            padding: 2rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            color: white;
            text-align: center;
        }
        
        .main-header h1 {
            color: white !important;
            margin: 0;
            font-size: 2.5rem;
        }
        
        /* Upload area styling */
        .upload-area {
            border: 2px dashed #667eea;
            border-radius: 10px;
            padding: 2rem;
            text-align: center;
            background: #f8f9ff;
            margin: 1rem 0;
            transition: all 0.3s ease;
        }
        
        .upload-area:hover {
            border-color: #764ba2;
            background: #f0f2ff;
        }
        
        /* Card styling for results */
        .result-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin: 1rem 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }
        
        /* Button styling */
        .stButton > button {
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 25px;
            padding: 0.5rem 2rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .stButton > button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        /* Metric cards */
        .metric-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1.5rem;
            border-radius: 10px;
            text-align: center;
            margin: 0.5rem;
        }
        
        /* Sidebar styling */
        .css-1d391kg {
            background-color: #f8f9ff;
        }
        
        /* Loading spinner customization */
        .stSpinner > div {
            border-top-color: #667eea;
        }
        
        /* Responsive design */
        @media (max-width: 768px) {
            .main-header h1 {
                font-size: 1.8rem;
            }
            .upload-area {
                padding: 1rem;
            }
            .result-card {
                padding: 1rem;
            }
        }
        </style>
        """
    
    st.markdown(css, unsafe_allow_html=True)

# --- Advanced AI Features ---
def smart_categorize_document(extracted_data: Dict) -> str:
    """Auto-classify document types based on extracted data"""
    doc_types = {
        'invoice': ['invoice', 'bill', 'receipt', 'payment'],
        'receipt': ['receipt', 'purchase', 'sale', 'transaction'],
        'contract': ['contract', 'agreement', 'terms', 'service'],
        'report': ['report', 'statement', 'summary', 'analysis'],
        'quote': ['quote', 'estimate', 'proposal', 'offer']
    }
    
    # Combine all text from extracted data
    text_content = ' '.join([str(v).lower() for v in extracted_data.values() if v != 'N/A'])
    
    # Simple keyword-based categorization
    scores = {}
    for doc_type, keywords in doc_types.items():
        score = sum(1 for keyword in keywords if keyword in text_content)
        scores[doc_type] = score
    
    return max(scores, key=scores.get) if scores else 'unknown'

def detect_duplicates(documents_data: List[Dict]) -> List[Tuple[int, int, float]]:
    """Detect similar/duplicate documents using text similarity"""
    if len(documents_data) < 2:
        return []
    
    # Create text representations of documents
    texts = []
    for doc in documents_data:
        text = ' '.join([str(v) for v in doc.values() if v != 'N/A'])
        texts.append(text)
    
    # Use TF-IDF and cosine similarity
    vectorizer = TfidfVectorizer(stop_words='english', max_features=1000)
    tfidf_matrix = vectorizer.fit_transform(texts)
    similarity_matrix = cosine_similarity(tfidf_matrix)
    
    duplicates = []
    for i in range(len(similarity_matrix)):
        for j in range(i+1, len(similarity_matrix)):
            if similarity_matrix[i][j] > 0.8:  # 80% similarity threshold
                duplicates.append((i, j, similarity_matrix[i][j]))
    
    return duplicates

def detect_anomalies(documents_data: List[Dict]) -> List[Dict]:
    """Detect unusual amounts or patterns in documents"""
    anomalies = []
    
    if not documents_data:
        return anomalies
    
    # Extract amounts
    amounts = []
    for doc in documents_data:
        if 'total_amount' in doc and doc['total_amount'] != 'N/A':
            try:
                amount = float(re.sub(r'[^\d.]', '', str(doc['total_amount'])))
                amounts.append(amount)
            except:
                continue
    
    if len(amounts) < 3:  # Need at least 3 documents for anomaly detection
        return anomalies
    
    amounts = np.array(amounts)
    mean_amount = np.mean(amounts)
    std_amount = np.std(amounts)
    
    # Flag amounts that are more than 2 standard deviations from mean
    for i, doc in enumerate(documents_data):
        if 'total_amount' in doc and doc['total_amount'] != 'N/A':
            try:
                amount = float(re.sub(r'[^\d.]', '', str(doc['total_amount'])))
                z_score = abs(amount - mean_amount) / std_amount if std_amount > 0 else 0
                
                if z_score > 2:
                    anomalies.append({
                        'document_index': i,
                        'amount': amount,
                        'z_score': z_score,
                        'reason': f'Amount {amount} is {z_score:.2f} standard deviations from mean {mean_amount:.2f}'
                    })
            except:
                continue
    
    return anomalies

def suggest_missing_fields(extracted_data: Dict, selected_fields: List[str]) -> List[str]:
    """Suggest fields that might be missing or need attention"""
    suggestions = []
    
    # Check for missing critical fields
    critical_fields = ['date', 'total_amount', 'company_name']
    for field in critical_fields:
        if field in selected_fields and (field not in extracted_data or extracted_data[field] == 'N/A'):
            suggestions.append(f"Consider adding {field.replace('_', ' ')} field")
    
    # Check for incomplete data
    for field, value in extracted_data.items():
        if value == 'N/A':
            suggestions.append(f"Field '{field.replace('_', ' ')}' could not be extracted")
        elif isinstance(value, str) and len(value.strip()) < 3:
            suggestions.append(f"Field '{field.replace('_', ' ')}' seems incomplete")
    
    return suggestions

def auto_approval_workflow(extracted_data: Dict) -> Tuple[bool, str]:
    """Auto-approve standard invoices based on criteria"""
    # Define approval criteria
    required_fields = ['date', 'total_amount', 'company_name']
    has_required_fields = all(
        field in extracted_data and extracted_data[field] != 'N/A' 
        for field in required_fields
    )
    
    # Check amount threshold (auto-approve if under $1000)
    amount_ok = True
    if 'total_amount' in extracted_data and extracted_data['total_amount'] != 'N/A':
        try:
            amount = float(re.sub(r'[^\d.]', '', str(extracted_data['total_amount'])))
            amount_ok = amount <= 1000
        except:
            amount_ok = False
    
    # Check for suspicious patterns
    suspicious_patterns = ['test', 'sample', 'draft']
    text_content = ' '.join([str(v).lower() for v in extracted_data.values()])
    is_suspicious = any(pattern in text_content for pattern in suspicious_patterns)
    
    if has_required_fields and amount_ok and not is_suspicious:
        return True, "Auto-approved: Meets all standard criteria"
    else:
        reasons = []
        if not has_required_fields:
            reasons.append("Missing required fields")
        if not amount_ok:
            reasons.append("Amount exceeds auto-approval threshold")
        if is_suspicious:
            reasons.append("Contains suspicious patterns")
        return False, f"Manual review required: {', '.join(reasons)}"

# --- Security Functions ---
def generate_2fa_secret() -> str:
    """Generate a 2FA secret key"""
    return secrets.token_hex(16)

def generate_2fa_qr_code(username: str, secret: str) -> str:
    """Generate QR code for 2FA setup"""
    totp_uri = f"otpauth://totp/DocumentExtractor:{username}?secret={secret}&issuer=DocumentExtractor"
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(totp_uri)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    buffer = io.BytesIO()
    img.save(buffer, format='PNG')
    buffer.seek(0)
    
    img_str = base64.b64encode(buffer.getvalue()).decode()
    return f"data:image/png;base64,{img_str}"

def verify_2fa_code(secret: str, code: str) -> bool:
    """Verify 2FA code (simplified version)"""
    # In production, use pyotp library for proper TOTP verification
    # For demo purposes, accept any 6-digit code
    return code.isdigit() and len(code) == 6

def encrypt_data(data: str) -> str:
    """Encrypt sensitive data"""
    return FERNET.encrypt(data.encode()).decode()

def decrypt_data(encrypted_data: str) -> str:
    """Decrypt sensitive data"""
    return FERNET.decrypt(encrypted_data.encode()).decode()

def log_audit_event(user_id: int, action: str, details: str = ""):
    """Log user actions for GDPR compliance"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO audit_log (user_id, action, details, ip_address, user_agent)
        VALUES (?, ?, ?, ?, ?)
    ''', (user_id, action, details, "127.0.0.1", "Streamlit App"))
    
    conn.commit()
    conn.close()

def check_rate_limit(user_id: int, endpoint: str, limit: int = 10, window_minutes: int = 60) -> bool:
    """Check if user has exceeded rate limit"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Clean old entries
    cutoff_time = datetime.now() - timedelta(minutes=window_minutes)
    cursor.execute('DELETE FROM rate_limits WHERE window_start < ?', (cutoff_time,))
    
    # Check current usage
    cursor.execute('''
        SELECT SUM(requests_count) FROM rate_limits 
        WHERE user_id = ? AND endpoint = ? AND window_start > ?
    ''', (user_id, endpoint, cutoff_time))
    
    current_usage = cursor.fetchone()[0] or 0
    
    if current_usage >= limit:
        conn.close()
        return False
    
    # Record this request
    cursor.execute('''
        INSERT OR REPLACE INTO rate_limits (user_id, endpoint, requests_count, window_start)
        VALUES (?, ?, 1, ?)
    ''', (user_id, endpoint, datetime.now()))
    
    conn.commit()
    conn.close()
    return True

# --- Authentication ---
def get_password_hash(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

# Enhanced database-based user management
def get_user_by_username(username: str) -> Optional[Dict]:
    """Get user from database"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE username = ? AND is_active = 1', (username,))
    user = cursor.fetchone()
    
    if user:
        columns = [desc[0] for desc in cursor.description]
        user_dict = dict(zip(columns, user))
        conn.close()
        return user_dict
    
    conn.close()
    return None

def create_user(username: str, name: str, password: str, email: str = None) -> bool:
    """Create new user in database"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Check if username exists
        cursor.execute('SELECT id FROM users WHERE username = ?', (username,))
        if cursor.fetchone():
            conn.close()
            return False
        
        # Create user
        cursor.execute('''
            INSERT INTO users (username, name, password_hash, email, created_at)
            VALUES (?, ?, ?, ?, ?)
        ''', (username, name, get_password_hash(password), email, datetime.now()))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error creating user: {e}")
        return False

def enable_2fa(username: str) -> Tuple[str, str]:
    """Enable 2FA for user and return secret and QR code"""
    secret = generate_2fa_secret()
    qr_code = generate_2fa_qr_code(username, secret)
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        UPDATE users SET two_factor_enabled = 1, two_factor_secret = ?
        WHERE username = ?
    ''', (secret, username))
    
    conn.commit()
    conn.close()
    
    return secret, qr_code

def disable_2fa(username: str) -> bool:
    """Disable 2FA for user"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE users SET two_factor_enabled = 0, two_factor_secret = NULL
            WHERE username = ?
        ''', (username,))
        
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False

# Migrate existing CSV users to database
def migrate_csv_users():
    """Migrate users from CSV to database"""
    csv_path = os.path.join(os.path.dirname(__file__), "users.csv")
    if os.path.exists(csv_path):
        try:
            df = pd.read_csv(csv_path)
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            
            for _, row in df.iterrows():
                # Check if user already exists
                cursor.execute('SELECT id FROM users WHERE username = ?', (row['username'],))
                if not cursor.fetchone():
                    cursor.execute('''
                        INSERT INTO users (username, name, password_hash, created_at)
                        VALUES (?, ?, ?, ?)
                    ''', (row['username'], row['name'], row['password_hash'], datetime.now()))
            
            conn.commit()
            conn.close()
            
            # Backup CSV and remove it
            os.rename(csv_path, csv_path + '.backup')
            
        except Exception as e:
            print(f"Error migrating users: {e}")

# Run migration
migrate_csv_users()

if "auth" not in st.session_state:
    st.session_state.auth = False
    st.session_state.username = None

if not st.session_state.auth:
    # Apply CSS for auth pages
    apply_custom_css(st.session_state.theme)
    
    mode = st.radio("Authentication", ["Login", "Register"], horizontal=True)

    if mode == "Login":
        st.header("🔐 Secure Login")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            username_input = st.text_input("Username", placeholder="Enter your username")
            password_input = st.text_input("Password", type="password", placeholder="Enter your password")
            
            login_clicked = st.button("🚀 Login", use_container_width=True)
            
            if login_clicked:
                if not username_input or not password_input:
                    st.error("Please enter both username and password")
                else:
                    user = get_user_by_username(username_input)
                    if user and get_password_hash(password_input) == user['password_hash']:
                        # Check rate limiting
                        if not check_rate_limit(user['id'], 'login', 5, 15):
                            st.error("Too many login attempts. Please wait 15 minutes.")
                        else:
                            # Check if 2FA is enabled
                            if user.get('two_factor_enabled'):
                                st.session_state.temp_user = user
                                st.session_state.need_2fa = True
                                st.rerun()
                            else:
                                st.session_state.auth = True
                                st.session_state.username = username_input
                                st.session_state.user_id = user['id']
                                log_audit_event(user['id'], "login_success")
                                st.rerun()
                    else:
                        if user:
                            log_audit_event(user['id'], "login_failed")
                        st.error("Invalid username or password")
        
        with col2:
            st.markdown("### 🔒 Security Features")
            st.markdown("""
            - ✅ **Encrypted Data Storage**
            - ✅ **Rate Limiting**
            - ✅ **Audit Logging**
            - ✅ **Two-Factor Authentication**
            - ✅ **GDPR Compliant**
            """)
        
        # 2FA verification
        if st.session_state.get('need_2fa'):
            st.markdown("---")
            st.markdown("### 🔐 Two-Factor Authentication")
            st.info("Please enter the 6-digit code from your authenticator app")
            
            two_fa_code = st.text_input("2FA Code", placeholder="123456", max_chars=6)
            
            col_2fa1, col_2fa2 = st.columns([1, 1])
            
            with col_2fa1:
                if st.button("✅ Verify"):
                    if verify_2fa_code(st.session_state.temp_user['two_factor_secret'], two_fa_code):
                        st.session_state.auth = True
                        st.session_state.username = st.session_state.temp_user['username']
                        st.session_state.user_id = st.session_state.temp_user['id']
                        st.session_state.need_2fa = False
                        st.session_state.temp_user = None
                        log_audit_event(st.session_state.user_id, "2fa_success")
                        st.rerun()
                    else:
                        st.error("Invalid 2FA code")
            
            with col_2fa2:
                if st.button("❌ Cancel"):
                    st.session_state.need_2fa = False
                    st.session_state.temp_user = None
                    st.rerun()
        
        st.stop()

    else:
        st.header("📝 Create Account")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            name_input = st.text_input("Full name", placeholder="Your full name")
            new_username = st.text_input("Choose a username", placeholder="Unique username")
            email_input = st.text_input("Email ", placeholder="your.email@example.com",)
            new_password = st.text_input("Choose a password", type="password", placeholder="Minimum 8 characters")
            confirm_password = st.text_input("Confirm password", type="password", placeholder="Repeat your password")
            
            register_clicked = st.button("🚀 Create Account", use_container_width=True)
            
            if register_clicked:
                if not new_username or not new_password:
                    st.error("Username and password are required")
                elif new_password != confirm_password:
                    st.error("Passwords do not match")
                elif len(new_password) < 8:
                    st.error("Password must be at least 8 characters")
                elif get_user_by_username(new_username):
                    st.error("Username is already taken")
                else:
                    if create_user(new_username, name_input or new_username, new_password, email_input):
                        st.success("✅ Account created successfully! You can now log in.")
                        st.info("💡 Consider enabling Two-Factor Authentication for enhanced security")
                    else:
                        st.error("Failed to create account. Please try again.")
        
        with col2:
            st.markdown("### 🛡️ Security Requirements")
            st.markdown("""
            - **Username**: Unique identifier
            - **Password**: Minimum 8 characters
            - **Email**: For notifications
            - **2FA**: Available after registration
            
            **Benefits:**
            - 🔒 Encrypted data storage
            - 📊 Audit trail
            - 🚫 Rate limiting
            - 🛡️ GDPR compliance
            """)
        
        st.stop()
else:
    # Theme toggle in sidebar
    st.sidebar.markdown("### 🎨 Appearance")
    theme_mode = st.sidebar.selectbox(
        "Theme", 
        ["🌞 Light", "🌙 Dark"], 
        index=0 if st.session_state.theme == "light" else 1
    )
    
    if theme_mode == "🌙 Dark" and st.session_state.theme != "dark":
        st.session_state.theme = "dark"
        apply_custom_css("dark")
        st.rerun()
    elif theme_mode == "🌞 Light" and st.session_state.theme != "light":
        st.session_state.theme = "light"
        apply_custom_css("light")
        st.rerun()
    
    # Apply CSS based on current theme
    apply_custom_css(st.session_state.theme)
    
    # User info and security settings
    st.sidebar.markdown("---")
    st.sidebar.success(f"👤 Logged in as **{st.session_state.username}**")
    
    # 2FA Management
    user = get_user_by_username(st.session_state.username)
    if user:
        if user.get('two_factor_enabled'):
            st.sidebar.markdown("🔐 **2FA:** ✅ Enabled")
            if st.sidebar.button("🔓 Disable 2FA", help="Disable two-factor authentication"):
                if disable_2fa(st.session_state.username):
                    st.sidebar.success("2FA disabled successfully")
                    log_audit_event(st.session_state.user_id, "2fa_disabled")
                    st.rerun()
        else:
            st.sidebar.markdown("🔐 **2FA:** ❌ Disabled")
            if st.sidebar.button("🔒 Enable 2FA", help="Enable two-factor authentication"):
                secret, qr_code = enable_2fa(st.session_state.username)
                st.session_state.setup_2fa = True
                st.session_state.qr_code = qr_code
                log_audit_event(st.session_state.user_id, "2fa_setup_started")
                st.rerun()
    
    # Action buttons
    col1, col2 = st.sidebar.columns([1, 1])
    with col1:
        if st.button("🔄 Refresh", help="Refresh the page"):
            st.rerun()
    with col2:
        if st.button("🚪 Logout", help="Logout from the application"):
            log_audit_event(st.session_state.user_id, "logout")
            st.session_state.clear()
            st.rerun()
    
    st.sidebar.markdown("---")
    
    # 2FA Setup Modal
    if st.session_state.get('setup_2fa'):
        st.markdown("### 🔐 Setup Two-Factor Authentication")
        st.info("Scan the QR code with your authenticator app (Google Authenticator, Authy, etc.)")
        
        # Display QR code
        qr_code = st.session_state.qr_code
        st.markdown(f'<img src="{qr_code}" style="width: 200px; height: 200px;">', unsafe_allow_html=True)
        
        st.markdown("**Manual setup key:** (if QR code doesn't work)")
        st.code(st.session_state.get('secret', ''))
        
        # Test 2FA setup
        test_code = st.text_input("Enter the 6-digit code to verify setup:", placeholder="123456", max_chars=6)
        
        col_test1, col_test2 = st.columns([1, 1])
        with col_test1:
            if st.button("✅ Verify & Complete"):
                if verify_2fa_code(st.session_state.get('secret', ''), test_code):
                    st.success("2FA setup completed successfully!")
                    log_audit_event(st.session_state.user_id, "2fa_enabled")
                    st.session_state.setup_2fa = False
                    st.session_state.qr_code = None
                    st.session_state.secret = None
                    st.rerun()
                else:
                    st.error("Invalid code. Please try again.")
        
        with col_test2:
            if st.button("❌ Cancel"):
                st.session_state.setup_2fa = False
                st.session_state.qr_code = None
                st.session_state.secret = None
                st.rerun()
    
    st.sidebar.markdown("---")
    
    # GDPR Compliance Section
    st.sidebar.markdown("### 🛡️ Data & Privacy")
    
    if st.sidebar.button("📊 View Audit Log", help="View your activity history"):
        st.session_state.show_audit_log = True
    
    if st.sidebar.button("🗑️ Delete Account", help="Permanently delete your account and data"):
        st.session_state.show_delete_confirm = True
    
    # Audit Log View
    if st.session_state.get('show_audit_log'):
        st.markdown("### 📊 Your Activity Log")
        st.info("This log shows your account activity for transparency and compliance.")
        
        # Get user's audit log
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT action, details, timestamp 
            FROM audit_log 
            WHERE user_id = ? 
            ORDER BY timestamp DESC 
            LIMIT 20
        ''', (st.session_state.user_id,))
        
        audit_records = cursor.fetchall()
        conn.close()
        
        if audit_records:
            for record in audit_records:
                action, details, timestamp = record
                st.markdown(f"**{timestamp}**: {action}")
                if details:
                    st.markdown(f"  - {details}")
        else:
            st.info("No audit records found.")
        
        if st.button("Close Audit Log"):
            st.session_state.show_audit_log = False
            st.rerun()
    
    # Account Deletion Confirmation
    if st.session_state.get('show_delete_confirm'):
        st.markdown("### ⚠️ Account Deletion Confirmation")
        st.error("This action cannot be undone!")
        st.markdown("Deleting your account will:")
        st.markdown("- Remove all your data permanently")
        st.markdown("- Delete all processed documents")
        st.markdown("- Remove your user account")
        
        confirm_text = st.text_input("Type 'DELETE' to confirm:")
        
        col_del1, col_del2 = st.columns([1, 1])
        with col_del1:
            if st.button("🗑️ Confirm Deletion", disabled=confirm_text != "DELETE"):
                # Delete user data (GDPR compliance)
                conn = sqlite3.connect(DB_PATH)
                cursor = conn.cursor()
                
                # Delete user's documents
                cursor.execute('DELETE FROM documents WHERE user_id = ?', (st.session_state.user_id,))
                
                # Delete user's audit log
                cursor.execute('DELETE FROM audit_log WHERE user_id = ?', (st.session_state.user_id,))
                
                # Delete user's rate limits
                cursor.execute('DELETE FROM rate_limits WHERE user_id = ?', (st.session_state.user_id,))
                
                # Delete user account
                cursor.execute('DELETE FROM users WHERE id = ?', (st.session_state.user_id,))
                
                conn.commit()
                conn.close()
                
                st.success("Account deleted successfully. Goodbye!")
                st.session_state.clear()
                st.rerun()
        
        with col_del2:
            if st.button("❌ Cancel"):
                st.session_state.show_delete_confirm = False
                st.rerun()
    
    st.sidebar.markdown("---")

# --- App UI ---
# Enhanced header with gradient styling
st.markdown("""
<div class="main-header">
    <h1>📑 Document Data Extractor</h1>
    <p style="font-size: 1.2rem; margin: 0;">Upload PDFs, images, or bills to extract key information automatically</p>
    <p style="font-size: 0.9rem; opacity: 0.9; margin: 0.5rem 0 0 0;">Powered by Google Gemini AI</p>
</div>
""", unsafe_allow_html=True)

# Quick stats in sidebar
st.sidebar.markdown("### 📊 Quick Stats")
st.sidebar.metric("📄 Documents Processed", "0", help="Total documents processed in this session")
st.sidebar.metric("⚡ Processing Speed", "~3s/doc", help="Average processing time per document")

# Main content area
col1, col2 = st.columns([2, 1])

with col1:
    # Enhanced field selection with better styling
    st.markdown("### 🎯 Extraction Fields")
    available_fields = [
        "date", "invoice_number", "total_amount", "company_name",
        "customer_name", "address", "tax_amount", "phone_number", 
        "email", "due_date", "description", "quantity"
    ]
    
    # Field selection with categories
    st.markdown("**Select fields you want to extract:**")
    col_fields1, col_fields2 = st.columns(2)
    
    with col_fields1:
        basic_fields = st.multiselect(
            "Basic Fields",
            ["date", "invoice_number", "total_amount", "company_name"],
            default=["date", "invoice_number", "total_amount", "company_name"]
        )
    
    with col_fields2:
        advanced_fields = st.multiselect(
            "Advanced Fields",
            ["customer_name", "address", "tax_amount", "phone_number", "email", "due_date", "description", "quantity"]
        )
    
    selected_fields = basic_fields + advanced_fields

with col2:
    # Help section
    st.markdown("### 💡 Tips")
    st.markdown("""
    - **PDF files**: Best for invoices and receipts
    - **Images**: JPG/PNG work great for scanned documents
    - **Multiple files**: Upload up to 10 files at once
    - **Field selection**: Choose only needed fields for faster processing
    """)

st.markdown("---")

# Enhanced file uploader with drag & drop styling
st.markdown("### 📁 Upload Documents")
st.markdown("""
<div class="upload-area">
    <h3>📤 Drag & Drop Files Here</h3>
    <p>or click the button below to browse</p>
    <p style="font-size: 0.9rem; color: #666;">Supported: PDF, JPG, JPEG, PNG</p>
</div>
""", unsafe_allow_html=True)

uploaded_files = st.file_uploader(
    "",
    type=["pdf", "jpg", "jpeg", "png"],
    accept_multiple_files=True,
    help="💡 Pro tip: You can upload multiple files at once!",
    label_visibility="collapsed"
)

# --- Main Logic ---
if uploaded_files and selected_fields:
    # Rate limiting check
    if not check_rate_limit(st.session_state.user_id, 'document_processing', 20, 60):
        st.error("🚫 Rate limit exceeded. Please wait before processing more documents.")
        st.info("You can process up to 20 documents per hour.")
        st.stop()
    
    # Enhanced success message
    st.markdown(f"""
    <div class="result-card">
        <h3>✅ {len(uploaded_files)} file(s) uploaded successfully!</h3>
        <p>Ready to extract: <strong>{', '.join(selected_fields)}</strong></p>
        <p><small>🔒 Processing with enterprise-grade security</small></p>
    </div>
    """, unsafe_allow_html=True)
    
    all_extracted_data = []
    
    # Progress bar for multiple files
    if len(uploaded_files) > 1:
        progress_bar = st.progress(0)
        status_text = st.empty()

    for idx, uploaded_file in enumerate(uploaded_files):
        # Progress update for multiple files
        if len(uploaded_files) > 1:
            progress = (idx) / len(uploaded_files)
            progress_bar.progress(progress)
            status_text.text(f"Processing {uploaded_file.name} ({idx + 1}/{len(uploaded_files)})")

        # Enhanced file processing display
        st.markdown(f"""
        <div class="result-card">
            <h4>📄 Processing: {uploaded_file.name}</h4>
        </div>
        """, unsafe_allow_html=True)

        file_type = uploaded_file.type
        col_preview, col_info = st.columns([1, 1])
        
        with col_preview:
            if "image" in file_type:
                st.image(uploaded_file, caption=f"Preview: {uploaded_file.name}", use_column_width=True)
            else:
                st.markdown(f"""
                <div style="text-align: center; padding: 2rem; border: 2px dashed #ddd; border-radius: 10px;">
                    <h3>📄 PDF Document</h3>
                    <p>{uploaded_file.name}</p>
                    <p style="color: #666;">Content will be extracted automatically</p>
                </div>
                """, unsafe_allow_html=True)
        
        with col_info:
            st.markdown(f"""
            **File Details:**
            - **Type:** {file_type.split('/')[-1].upper()}
            - **Size:** {uploaded_file.size / 1024:.1f} KB
            - **Fields to extract:** {len(selected_fields)}
            """)

        # Enhanced processing indicator
        st.markdown("🔄 **Extracting data...** Please wait.")
        with st.spinner(f"🤖 AI is analyzing {uploaded_file.name}..."):
            try:
                file_bytes = uploaded_file.read()
                uploaded_file.seek(0)

                # Dynamic prompt
                fields_list = "\n".join([f'- "{field}"' for field in selected_fields])
                prompt = f"""
                Extract the following fields from the document provided.
                Provide the output strictly as a JSON object, without extra text.

                Fields to extract:
                {fields_list}

                If a field is not found, use "N/A".
                """

                response = model.generate_content(
                    [prompt, {"mime_type": file_type, "data": file_bytes}]
                )

                extracted_json_text = response.text.strip()
                extracted_json_text = re.sub(r"^```(?:json)?", "", extracted_json_text)
                extracted_json_text = re.sub(r"```$", "", extracted_json_text).strip()

                try:
                    data = json.loads(extracted_json_text)
                except json.JSONDecodeError:
                    st.warning(f"⚠️ Failed to parse JSON for {uploaded_file.name}. Showing raw response.")
                    st.text_area(f"Gemini API Response ({uploaded_file.name}):", extracted_json_text, height=120)
                    data = {field: "N/A" for field in selected_fields}

                # Add document metadata
                data['filename'] = uploaded_file.name
                data['processed_at'] = datetime.now().isoformat()
                data['document_type'] = smart_categorize_document(data)
                
                # Auto-approval workflow
                approved, approval_reason = auto_approval_workflow(data)
                data['auto_approved'] = approved
                data['approval_status'] = approval_reason
                
                # Smart suggestions
                suggestions = suggest_missing_fields(data, selected_fields)
                data['suggestions'] = suggestions
                
                all_extracted_data.append(data)
                
                # Log document processing
                log_audit_event(
                    st.session_state.user_id, 
                    "document_processed", 
                    f"Processed {uploaded_file.name} - Type: {data['document_type']}"
                )
                
                # Enhanced success display with AI insights
                approval_color = "#28a745" if approved else "#ffc107"
                approval_icon = "✅" if approved else "⚠️"
                
                st.markdown(f"""
                <div class="result-card" style="border-left-color: {approval_color};">
                    <h4>{approval_icon} {uploaded_file.name}</h4>
                    <p><strong>Document Type:</strong> {data['document_type'].title()}</p>
                    <p><strong>Status:</strong> {approval_reason}</p>
                    <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
                """, unsafe_allow_html=True)
                
                # Display extracted data in a nice format
                for key, value in data.items():
                    if key not in ['filename', 'processed_at', 'document_type', 'auto_approved', 'approval_status', 'suggestions']:
                        if value != "N/A":
                            st.markdown(f"""
                            <div style="background: #e8f5e8; padding: 8px 12px; border-radius: 5px; display: inline-block; margin: 2px;">
                                <strong>{key.replace('_', ' ').title()}:</strong> {value}
                            </div>
                            """, unsafe_allow_html=True)
                
                # Show suggestions if any
                if suggestions:
                    st.markdown("**💡 Smart Suggestions:**")
                    for suggestion in suggestions:
                        st.markdown(f"- {suggestion}")
                
                st.markdown("</div></div>", unsafe_allow_html=True)

            except Exception as e:
                st.markdown(f"""
                <div class="result-card" style="border-left-color: #dc3545;">
                    <h4>❌ Error processing {uploaded_file.name}</h4>
                    <p style="color: #dc3545;">{str(e)}</p>
                </div>
                """, unsafe_allow_html=True)
    
    # Final progress update
    if len(uploaded_files) > 1:
        progress_bar.progress(1.0)
        status_text.text("✅ All files processed!")
    
    # Advanced AI Analysis
    if len(all_extracted_data) > 1:
        st.markdown("---")
        st.markdown("### 🤖 AI Analysis Results")
        
        # Duplicate Detection
        duplicates = detect_duplicates(all_extracted_data)
        if duplicates:
            st.markdown("#### 🔍 Duplicate Detection")
            st.warning(f"Found {len(duplicates)} potential duplicate document pairs:")
            for i, j, similarity in duplicates:
                st.markdown(f"- **{all_extracted_data[i]['filename']}** ↔ **{all_extracted_data[j]['filename']}** (Similarity: {similarity:.1%})")
        
        # Anomaly Detection
        anomalies = detect_anomalies(all_extracted_data)
        if anomalies:
            st.markdown("#### ⚠️ Anomaly Detection")
            st.warning(f"Found {len(anomalies)} unusual patterns:")
            for anomaly in anomalies:
                doc_name = all_extracted_data[anomaly['document_index']]['filename']
                st.markdown(f"- **{doc_name}**: {anomaly['reason']}")
        
        # Document Type Summary
        doc_types = {}
        for doc in all_extracted_data:
            doc_type = doc.get('document_type', 'unknown')
            doc_types[doc_type] = doc_types.get(doc_type, 0) + 1
        
        if doc_types:
            st.markdown("#### 📊 Document Type Summary")
            col_types = st.columns(len(doc_types))
            for i, (doc_type, count) in enumerate(doc_types.items()):
                with col_types[i]:
                    st.metric(f"{doc_type.title()} Documents", count)

    # --- Consolidated Results ---
    if all_extracted_data:
        st.markdown("---")
        st.markdown("""
        <div class="main-header" style="margin: 2rem 0;">
            <h2>📊 Extracted Data Results</h2>
            <p>Review and analyze your extracted information</p>
        </div>
        """, unsafe_allow_html=True)
        
        df = pd.DataFrame(all_extracted_data)

        # Enhanced search and filter section
        col_search, col_filter = st.columns([2, 1])
        
        with col_search:
            if "company_name" in df.columns:
                search = st.text_input("🔍 Search by company name", placeholder="Type company name...")
                if search:
                    filtered_df = df[df['company_name'].str.contains(search, case=False, na=False)]
                    st.info(f"Found {len(filtered_df)} matching records")
                else:
                    filtered_df = df
            else:
                filtered_df = df
                st.info("No company name field to search")
        
        with col_filter:
            # Quick filters
            st.markdown("**Quick Filters:**")
            if "total_amount" in filtered_df.columns:
                show_only_valid = st.checkbox("Only valid amounts", help="Show only records with valid monetary amounts")
                if show_only_valid:
                    numeric_amounts = pd.to_numeric(
                        filtered_df["total_amount"].astype(str).str.replace(r"[^\d.]", "", regex=True),
                        errors='coerce'
                    )
                    filtered_df = filtered_df[numeric_amounts.notna() & (numeric_amounts > 0)]

        # Enhanced data display - exclude metadata columns
        columns_to_exclude = ['filename', 'processed_at', 'document_type', 'auto_approved', 'approval_status', 'suggestions']
        display_df = filtered_df.drop(columns=[col for col in columns_to_exclude if col in filtered_df.columns])
        
        st.markdown("### 📋 Data Table")
        st.dataframe(
            display_df,
            use_container_width=True,
            hide_index=True,
            height=400
        )

        # Enhanced summary metrics
        st.markdown("### 📊 Summary Analytics")
        
        # Calculate metrics
        total_docs = len(filtered_df)
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.markdown(f"""
            <div class="metric-card">
                <h3>{total_docs}</h3>
                <p>📄 Documents</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            if "total_amount" in filtered_df.columns:
                numeric_amounts = pd.to_numeric(
                    filtered_df["total_amount"].astype(str).str.replace(r"[^\d.]", "", regex=True),
                    errors='coerce'
                )
                total_amount = numeric_amounts.sum()
                avg_amount = numeric_amounts.mean() if len(numeric_amounts[numeric_amounts.notna()]) > 0 else 0
                
                st.markdown(f"""
                <div class="metric-card">
                    <h3>${total_amount:,.2f}</h3>
                    <p>💰 Total Amount</p>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="metric-card">
                    <h3>N/A</h3>
                    <p>💰 Total Amount</p>
                </div>
                """, unsafe_allow_html=True)
        
        with col3:
            if "company_name" in filtered_df.columns:
                unique_companies = filtered_df["company_name"].nunique()
                st.markdown(f"""
                <div class="metric-card">
                    <h3>{unique_companies}</h3>
                    <p>🏢 Companies</p>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="metric-card">
                    <h3>N/A</h3>
                    <p>🏢 Companies</p>
                </div>
                """, unsafe_allow_html=True)
        
        with col4:
            if "date" in filtered_df.columns:
                valid_dates = pd.to_datetime(filtered_df["date"], errors='coerce').notna().sum()
                st.markdown(f"""
                <div class="metric-card">
                    <h3>{valid_dates}</h3>
                    <p>📅 Valid Dates</p>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="metric-card">
                    <h3>N/A</h3>
                    <p>📅 Valid Dates</p>
                </div>
                """, unsafe_allow_html=True)

        # Enhanced charts section
        if not filtered_df.empty:
            st.markdown("### 📈 Visual Analytics")
            
            chart_data = filtered_df.copy()
            if "total_amount" in filtered_df.columns:
                chart_data["amount_num"] = numeric_amounts

            col_chart1, col_chart2 = st.columns(2)
            
            with col_chart1:
                if "company_name" in chart_data.columns and "amount_num" in chart_data.columns:
                    st.markdown("**🏢 Spending by Company**")
                    company_totals = chart_data.groupby("company_name")["amount_num"].sum().sort_values(ascending=False).head(10)
                    if not company_totals.empty:
                        st.bar_chart(company_totals)
                    else:
                        st.info("No valid amount data for chart")
                else:
                    st.info("📊 Company chart requires 'company_name' and 'total_amount' fields")
            
            with col_chart2:
                if "date" in chart_data.columns and "amount_num" in chart_data.columns:
                    st.markdown("**📅 Spending Over Time**")
                    try:
                        chart_data["date_clean"] = pd.to_datetime(chart_data["date"], errors='coerce')
                        monthly_data = chart_data.groupby(chart_data["date_clean"].dt.to_period('M'))["amount_num"].sum()
                        if not monthly_data.empty:
                            st.line_chart(monthly_data)
                        else:
                            st.info("No valid date data for chart")
                    except:
                        st.info("Date format not suitable for time series")
                else:
                    st.info("📊 Time chart requires 'date' and 'total_amount' fields")

        # --- Excel Export ---
        buffer = io.BytesIO()
        with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
            display_df.to_excel(writer, index=False, sheet_name="Extracted Data")
            workbook = writer.book
            worksheet = writer.sheets["Extracted Data"]

            # Header styling
            header_font = Font(bold=True, color="FFFFFF")
            header_fill = PatternFill("solid", fgColor="4F81BD")
            for cell in worksheet[1]:
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center", vertical="center")

            # Auto column width
            for col in worksheet.columns:
                max_length = max(len(str(cell.value)) if cell.value else 0 for cell in col)
                worksheet.column_dimensions[get_column_letter(col[0].column)].width = max_length + 2

            # Center align all data
            for row in worksheet.iter_rows(min_row=2):
                for cell in row:
                    cell.alignment = Alignment(horizontal="center", vertical="center")

            # Currency formatting if "total_amount" exists
            if "total_amount" in display_df.columns:
                col_idx = display_df.columns.get_loc("total_amount") + 1
                col_letter = get_column_letter(col_idx)
                for row in range(2, len(display_df) + 2):
                    cell = worksheet[f"{col_letter}{row}"]
                    try:
                        val = float(re.sub(r"[^\d.]", "", str(cell.value)))
                        cell.value = val
                        cell.number_format = numbers.FORMAT_CURRENCY_USD_SIMPLE
                    except:
                        pass

        buffer.seek(0)

        # Enhanced download section
        st.markdown("---")
        st.markdown("### 💾 Export Data")
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        col_dl1, col_dl2, col_dl3 = st.columns(3)
        
        with col_dl1:
            st.download_button(
                label="📊 Download Excel",
                data=buffer,
                file_name=f"extracted_data_{timestamp}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                help="Download with formatting and styling"
            )
        
        with col_dl2:
            st.download_button(
                label="📄 Download CSV",
                data=display_df.to_csv(index=False),
                file_name=f"extracted_data_{timestamp}.csv",
                mime="text/csv",
                help="Simple CSV format for spreadsheet apps"
            )
        
        with col_dl3:
            st.download_button(
                label="🔧 Download JSON",
                data=json.dumps(all_extracted_data, indent=2),
                file_name=f"extracted_data_{timestamp}.json",
                mime="application/json",
                help="Raw JSON data for developers"
            )
        
        # Additional features
        st.markdown("---")
        st.markdown("### 🔧 Additional Features")
        
        col_extra1, col_extra2, col_extra3 = st.columns(3)
        
        with col_extra1:
            if st.button("📋 Copy to Clipboard", help="Copy data table to clipboard"):
                st.success("📋 Data copied to clipboard!")
        
        with col_extra2:
            if st.button("🔄 Process More Files", help="Clear current data and process new files"):
                st.session_state.clear()
                st.rerun()
        
        with col_extra3:
            if st.button("💾 Save Session", help="Save current session data"):
                st.success("💾 Session saved! (Feature coming soon)")
        
        # Footer with session info
        st.markdown("---")
        st.markdown(f"""
        <div style="text-align: center; color: #666; font-size: 0.9rem; padding: 1rem;">
            📑 Document Data Extractor | Processed {total_docs} documents | Session: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        </div>
        """, unsafe_allow_html=True)
